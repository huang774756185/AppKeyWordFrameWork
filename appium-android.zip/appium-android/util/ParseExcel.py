#encoding=utf-8
import openpyxl
from openpyxl.styles import Border,Side,Font
from config.VarConfig import *
import time

class ParaseExcel(object):
    def __init__(self):
        self.workbook = None
        self.excelFile = None
        self.font = Font(color= None)#设置字体颜色
        self.RGBDict = {'red':'FFFF3030', 'green':'FF008B00'}

    def loadWorkBook(self, excelPathAndName):
        # 将Excel文件加载到内存，并获取workBook对象
        try:
            self.workbook = openpyxl.load_workbook(excelPathAndName)
        except Exception, e:
            raise e
        self.excelFile = excelPathAndName
        return self.workbook

    def getSheetByName(self,sheetName):
        # 根据sheet名称获取sheet对象
        try:
            # sheet=self.workbook.get_sheet_by_name(sheetName)
            sheet = self.workbook[sheetName]
            return sheet

        except Exception, e:
            raise e

    def getSheetByIndex(self,sheetIndex):
        try:
            sheetName=self.workbook.get_sheet_names()[sheetIndex]
        except Exception, e:
            raise e
        sheet = self.workbook.get_sheet_by_name(sheetName)
        return sheet

    def getRowsNumber(self, sheet):
        #获取sheet中有数据区域的结束行号
        return sheet.max_row


    def getColsNumber(self,sheet):
        #获取sheet中有数据区域的结束列号
        return sheet.max_column

    def getStratRowNumber (self,sheet):
        #获取sheet中有数据区域的开始的行号
        return sheet.min_row

    def getStartColNumber(self,sheet):
        #获取sheet中有数据区域的开始的行号
        return sheet.min_colum

    def getRow(self,sheet, rowNo):
        #获取sheet中某一行，返回的是这一行所有的数据内容组成的tuple
        #下标从1开始，sheet.rows[1]表示第一行
        try:
            list_row=[]
            for row in sheet.rows:

                list_row.append(row)
            return list_row[rowNo -1]
        except Exception, e:
            raise e

    def getColumn(self,sheet,colNo):
        try:
            list_col=[]
            for col in sheet.columns:
                list_col.append(col)
            return list_col[colNo-1]
        except Exception, e:
            raise e

    def getCellOfValue(self,sheet,coordinnate = None,rowNo = None,colsNo = None):
        #根据单元格所在的位置索引提取该单元格中的值，下标从1开始
        #sheet.cell(row=1,colum=1).value,表示excel中第一行第一列的值
        if coordinnate !=None:
            try:
                return sheet.cell(coordinnate = coordinnate).value
            except Exception, e:
                raise e

        elif coordinnate is None and rowNo is not None and colsNo is not None:
            try:
                return sheet.cell(row=rowNo,column=colsNo).value
            except Exception,e:
                raise
        else:
            raise Exception("Insufficient Coordinates of cell!")

    def getCellOfObject(self,sheet,coordinate= None,rowNo=None,colsNo = None):
        #获取某个单元格的对象，可以根据单元格所在位置的数字索引，也可直接根据Excel中单元格的编码及坐标
        #sheet.cell(sheet, row=rowNo,column=colsNo).value 或者sheet.cell(sheet,coordinate='A1')
        if coordinate !=None:
            try:
                return sheet.cell(coordinate=coordinate)
            except Exception, e:
                raise e
        elif coordinate ==None and rowNo is not None and colsNo is not None:
            try:
                return sheet.cell(row=rowNo,column=colsNo)
            except Exception, e:
                raise e

        else:
             raise Exception("Insufficient Coordinates of cell!")

    def writeCell(self,sheet,content,coordinate = None,rowNo = None,colsNo = None,style = None):
        #根据单元格编码坐标或者数字索引坐标写入数据
        #下标从1开始，参数style表示字体的颜色名字，如red，green
        if coordinate is not None:
            try:
                sheet.cell(coordinate=coordinate).value=content
                if style is not None:
                    sheet.cell(coordinate=coordinate).font=Font(color=self.RGBDict[style])
                self.workbook.save(self.excelFile)

            except Exception, e:
                raise e
        elif coordinate == None and rowNo is not None and colsNo is not None:
            try:
                sheet.cell(row=rowNo,column=colsNo).value = content
                if  style is not None:
                    sheet.cell(row=rowNo,column=colsNo).font=Font(color=self.RGBDict[style])
                self.workbook.save(self.excelFile)

            except Exception, e:
                raise e
        else:
            raise Exception("Insufficient Coordinates of cell!")

    def writeCellCurrentTime(self,sheet,coordinate=None,rowNo = None,colsNo = None):
        now = int(time.time())#显示为时间戳
        timeArray = time.localtime(now)
        currentTime = time.strftime("%Y - %m -%d %H: %M: %S",timeArray)
        if coordinate !=None:
            try:
                sheet.cell(coordinate=coordinate).value=currentTime
                self.workbook.save(self.excelFile)
            except Exception, e:
                raise e
        elif coordinate is None and rowNo is not None and colsNo is not None:
            try:
                sheet.cell(row=rowNo,column=colsNo).value=currentTime
                self.workbook.save(self.excelFile)
            except Exception, e:
                raise e

        else:
            raise Exception("Insufficient Coordinates of cell!")


if __name__=='__main__':
    pe=ParaseExcel()
    pe.loadWorkBook(ur'E:\工作\猎鹰\画像\现网\理财师业绩表.xlsx')
    sheet = pe.getSheetByName("Sheet1")

    # private_fund_achievement = pe.getColumn(sheet=sheet, colNo=3)
    # public_fund_achievement = pe.getColumn(sheet=sheet, colNo=4)
    # print private_fund_achievement[0].value
    # print len(sheet.rows)
    # percentage_list=[]
    #
    # for cell in private_fund_achievement[1::]:
    #     if cell.value >=long(3000):
    #         percentage_list.append(cell.value * 0.003)#跳点为0.3
    #
    #     elif cell.value <3000 and cell.value>=1500 :#跳点为0.2
    #         percentage_list.append(cell.value * 0.002)
    #     elif cell.value <1500 and cell.value >= 500:#跳点为0.1
    #         percentage_list.append(cell.value * 0.001)
    #     else:
    #         percentage_list.append(0.00)
    # pe.writeCell(sheet=sheet, content="percentage", rowNo=1, colsNo=6)
    # for i in range (len(percentage_list)):
    #     print percentage_list[i]
    #     pe.writeCell(sheet=sheet, content=percentage_list[i], rowNo=i+2, colsNo=6)
    #
    # print '写入成功'
    percentage_list = []
    private_fund_colNo = 2
    healthy_colNo =3
    percentage = 6
    for i in range(len(sheet.rows)-1):
        private_fund_achievement = pe.getRow(sheet=sheet,rowNo=i+2)[private_fund_colNo].value
        #print(pe.getRow(sheet=sheet,rowNo=i+2)[private_fund_colNo].value)
        healthy_achievement = pe.getRow(sheet=sheet, rowNo=i+2)[healthy_colNo].value
        #print(healthy_achievement)
        sumPercentage = private_fund_achievement+healthy_achievement*2
        if sumPercentage >= 3000:
            percentage_list.append(sumPercentage*0.03)
        elif (sumPercentage >= 1500) and sumPercentage < 3000:
            achievement = (private_fund_achievement+healthy_achievement*2)*0.002
            percentage_list.append(sumPercentage*0.02)
        elif(sumPercentage >= 500) and sumPercentage < 3000:
            percentage_list.append(sumPercentage*0.01)
        else:
            percentage_list.append(0.00)
    pe.writeCell(sheet=sheet, content="percentage(万)", rowNo=1, colsNo=percentage)
    for i in range(len(percentage_list)):
        print percentage_list[i]
        pe.writeCell(sheet=sheet, content=percentage_list[i], rowNo=i+2, colsNo=percentage)

    print '写入成功'

