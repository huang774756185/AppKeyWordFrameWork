#encoding=utf-8
import time,os
from datetime import datetime
from config.VarConfig import screenPicturesDir

def getCurrentDate():
    #获取当前日期
    timeTop = time.localtime()
    currentDate = str(timeTop.tm_year) + "-"+str(timeTop.tm_mon)+"-"+str(timeTop.tm_mday)
    return currentDate

def getCurrentTime():
    #获取当前时间
    timeStr =datetime.now()
    nowTime=timeStr.strftime('%H-%M-%S-%f')
    return nowTime

def createCurrentDateDir():
    #截图存取目录
    dirName =os.path.join(screenPicturesDir, getCurrentDate())
    if not os.path.exists(dirName):
        os.makedirs(dirName)
    return dirName