#encoding=utf-8
from appium.webdriver.common.mobileby import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class WaitUtil(object):
    def __init__(self,driver):
        self.locationTypeDict = {
            "xpath":By.XPATH,
            "id":By.ID,
            "name":By.NAME,
            "class_name":By.CLASS_NAME,
            "tag_name":By.TAG_NAME,
            "partial_link_text":By.PARTIAL_LINK_TEXT
        }
        self.driver = driver
        self.wait = WebDriverWait(self.driver,30)

    def visibilityOfElementLocated(self,locationType,locatorExpression,*arg):
        #显示等待页面元素出现，存在则返回该页面元素
        try:
            self.wait.until(
                EC.visibility_of_element_located(
                    (self.locationTypeDict[locationType.lower()],locatorExpression)
                )
            )
        except Exception, e:
            raise e