#encoding=utf-8

import pymysql as mdb


conn_config = {
        'host': 'localhost',
        'port': 3306,
        'username': 'huang',
        'password': '123456',
        'database': 'testnewman',
        'charset': 'utf8'
    }


class MySqlHelper(object):

    def __init__(self):
        self.host = conn_config['host']
        self.port = conn_config['port']
        self.username = conn_config['username']
        self.password = conn_config['password']
        self.database = conn_config['database']
        self.con = None
        self.cur = None
        try:
            self.con = mdb.connect(host=self.host, port=self.port,
                                   user=self.username, passwd=self.password, db=self.database)
            self.cur = self.con.cursor()
        except Exception, e:
            raise e
        print '连接成功'

    def con_close(self):
        if  self.con:
            self.con.close()
        else:
            print '连接不存在，请检查连接设置!'

    def fetch_all(self,sql):
        self.cur.execute(sql)
        data = self.cur.fetchall()
        for line in data:
            for i in range(len(line)):
                print line[i]
        return data

    def fetch_one(self,sql):
        self.cur.execute(sql)
        data = self.cur.fetchone()
        if data:
            return True
        else:
            return False

    def insert_data(self, sql):
        self.cur.execute(sql)


if __name__ == '__main__':

    shp = MySqlHelper()
    shp.fetch_all("select * from student")
