#encoding=utf-8
from selenium.webdriver.support.ui import WebDriverWait

def getElement(driver,locationType,locatorExpression):
    try:
        element =WebDriverWait(driver,10).until\
            (lambda x:x.find_element(by=locationType,value=locatorExpression))
        return element
    except Exception, e:
        raise e


def getElements(driver,locationType,locatorExpression):
    try:
        elements = WebDriverWait(driver,10).until\
            (lambda x:x.find_elements(by=locationType,value=locatorExpression))
        return elements
    except Exception, e:
        raise e