#encoding=utf-8

import os

PATH = lambda p: os.path.abspath(
    os.path.join(os.path.dirname(__file__), p)
)

apkPath_sxy = PATH("E:/apk/sxy_guanwang_v6.3.0.apk")
apkPath_smy = PATH("E:/apk/046.apk")
'''私享云安装启动配置'''
desired_caps_sxy = {
        'platformName': 'Android',
        'deviceName': 'Galaxy S9+',
        'platformVersion': '8.0',
        'app' :apkPath_sxy,
        'noReset': 'false',
        'appPackage': 'com.cgbsoft.privatefund',
        'appActivity': 'app.ndk.com.enter.mvp.ui.start.WelcomeActivity',
        'unicodeKeyboard':'true',
         'resetKeyboard':'true',
    }
desired_caps_sxy_noReset = {
        'platformName': 'Android',
        'deviceName': 'Galaxy S9+',
        'platformVersion': '8.0',
        'app' :apkPath_sxy,
        'noReset': 'true',
        'appPackage': 'com.cgbsoft.privatefund',
        'appActivity': 'app.ndk.com.enter.mvp.ui.start.WelcomeActivity',
        'unicodeKeyboard':'true',
         'resetKeyboard':'true',
    }
desired_caps_smy = {
        'platformName': 'Android',
        'deviceName': 'Galaxy S9+',
        'platformVersion': '8.0',
        'app': apkPath_smy,
        'noReset': 'false',
        'appPackage': 'com.simuyun.adviser',
        'appActivity': 'activity.main.SplashActivity',
        'unicodeKeyboard': 'true',
         'resetKeyboard': 'true'
    }
desired_caps_smy_noReset = {
        'platformName': 'Android',
        'deviceName': 'Galaxy S9+',
        'platformVersion': '8.0',
        'app': apkPath_smy,
        'noReset': 'true',
        'appPackage': 'com.simuyun.adviser',
        'appActivity': 'activity.main.SplashActivity',
        'unicodeKeyboard': 'true',
         'resetKeyboard': 'true'
    }

#当前文件目录的父目录所在的绝对路径
paraentDirPath = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
#截图文件保存路径
screenPicturesDir = paraentDirPath + "\\exceptionpictures\\"

#测试数据文件存放的绝对路径
dataFilePath=paraentDirPath+u"\\testData\\私享云黄煌测试用例.xlsx"

#测试数据文件中，测试用例表中部分列对应的数字序号
testCase_testCaseName = 2
testCase_testStepSheetName = 3
testCase_isExecute = 4
testCase_runTime = 5
testCase_testResult = 6

#用例测试数据文件中，部分列对应的数字号
testStep_testStepDescribe = 2
testStep_keyWords = 3
testStep_locationType = 4
testStep_locatorExpression = 5
testStep_operateValue = 6
testStep_runTime = 7
testStep_testResult = 8
testStep_errorInfo = 9
testStep_errorPic = 10