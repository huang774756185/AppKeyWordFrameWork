#encoding=utf-8

import Actions.LaunchApp
import Actions.Login
from appium import webdriver
import unittest
import os
PATH = lambda p: os.path.abspath(
    os.path.join(os.path.dirname(__file__), p)
)


class TestLogin(unittest.TestCase):

    def setUp(self):
        desired_caps = {}
        desired_caps['platformName'] = 'Android'
        desired_caps['platformVersion'] = '8.0'
        desired_caps['deviceName'] = 'FFK0217524007119'
        desired_caps['app'] = PATH("/Users/wangjinlong/Documents/workspace/Test/apps/sixiangyun-automation.apk")
        desired_caps['appPackage'] = 'com.cgbsoft.privatefund'
        desired_caps['noReset'] = 'false'
        desired_caps['appActivity'] = 'app.ndk.com.enter.mvp.ui.start.WelcomeActivity'

        self.driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)


    def tearDown(self):
        self.driver.quit()

    def test_login(self):
        self.driver.c

