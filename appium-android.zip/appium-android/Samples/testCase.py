#encoding=utf-8
from util.ParseExcel import ParaseExcel
from Actions.UiHandle import *
from config.VarConfig import *
import time
import traceback
import sys

#设置编码环境utf-8
reload(sys)
sys.setdefaultencoding("utf-8")

#创建解析Excel对象
excelObj = ParaseExcel()
#在内存中加载workbook对象
excelObj.loadWorkBook(dataFilePath)

#用例或用例步骤执行结束后，向excel中写入执行结果信息
def writeTestResult(sheetObj, rowNo, colsNo, testResult,
                    errorInfo = None,picPath = None):
    #测试结果成功颜色为绿色，失败为红色
    colorDict = {"pass":"green","faild":"red"}
    #区分"测试用例"和"测试步骤"中的测试执行时间和测试结果列
    colsDict ={
        "testCase":[testCase_runTime, testCase_testResult],
        "caseStep":[testStep_runTime, testStep_testResult]}
    try:
        #写入测试时间
        excelObj.writeCellCurrentTime(sheetObj,rowNo=rowNo,colsNo=colsDict[colsNo][0])
        #写入测试结果
        excelObj.writeCell(sheetObj,content=testResult,rowNo=rowNo, colsNo=colsDict[colsNo][1],
                           style=colorDict[testResult])
        if errorInfo and picPath:
            #在测试步骤sheet中，写入异常信息
            excelObj.writeCell(sheetObj,content=errorInfo,rowNo=rowNo,colsNo=testStep_errorInfo)
            #写入异常截图路径
            excelObj.writeCell(sheetObj,content=picPath,rowNo=rowNo,colsNo=testStep_errorPic)
        else:
            #如果测试步骤通过则清空异常信息及错误截图单元格
            excelObj.writeCell(sheetObj,content="",
                               rowNo=rowNo,colsNo=testStep_errorInfo)
            excelObj.writeCell(sheetObj,content="", rowNo=rowNo,colsNo=testStep_errorPic)

    except Exception, e:
        print u"写excel出错，",traceback.print_exc()





#
# #用例或用例步骤执行结束后，向Excel中写入执行结果信息
# def writeTestResult(sheetObj, rowNo, colsNo, testResult,
#                     errorInfo = None,picPath = None):
#     #测试通过结果信息为绿色，失败为红色
#     colorDict = {"pass":"green","faild":"red"}
#     #"测试用例"工作表和"用例步骤sheet表"都有测试执行时间和测试结果列，定义两个字典区分这两个列表
#     colsDict = {
#         "testCase":[testCase_runTime, testCase_testResult],
#        "caseStep": [testStep_runTime,testCase_testResult]}
#
#     try:
#         #在测试步骤sheet中，写入测试时间
#         excelObj.writeCellCurrentTime(sheetObj,rowNo=rowNo,colsNo=colsDict[colsNo][0])
#
#         #在测试步骤sheet中，写入测试结果
#         excelObj.writeCell(sheetObj,content=testResult,rowNo=rowNo,colsNo=colsDict[colsNo][1],
#                            style=colorDict[testResult])
#
#         if errorInfo and picPath:
#             #在测试步骤sheet中，写入异常信息
#             excelObj.writeCell(sheetObj,content=errorInfo,
#                                rowNo = rowNo,colsNo=testStep_errorInfo)
#
#             #在测试步骤sheet中，写入异常截图路径
#
#             excelObj.writeCell(sheetObj,content=picPath,rowNo=rowNo,colsNo=testStep_errorPic)
#         else:
#             #在测试步骤sheet中，清空异常信息单元格
#             excelObj.writeCell(sheetObj,content="",
#                                rowNo = rowNo,colsNo=testStep_errorInfo)
#
#             #在测试步骤sheet中，清空错误截图单元格
#             excelObj.writeCell(sheetObj,content="",
#                                rowNo=rowNo,colsNo=testStep_errorPic)
#
#     except Exception, e:
#         print u"写excel出错,",traceback.print_exc()
#
def runCase():
    try:
        #根据Excel文件中的sheet名获取sheet对象
        caseSheet = excelObj.getSheetByName(u"测试用例")
        #获取测试用例sheet中“是否执行”列对象
        isExecuteColumn = excelObj.getColumn(caseSheet,testCase_isExecute)

        #记录执行成功的测试用例个数
        successfulCase = 0
        #记录需要执行的用例个数
        requiredCase = 0
        for idx, i in enumerate(isExecuteColumn[1:]):
            #第一行为标题行，无需执行
            print idx
            print i.value
            #循环遍历"测试用例"表中的测试用例，执行被设置为“执行”的用例
            # requiredCase += 1
            # 获取“测试用例”表中第idx+2行数据
            caseRow = excelObj.getRow(caseSheet, idx + 2)
            # 获取“测试用例”中“步骤sheet”单元格的名字
            caseStepSheetName = caseRow[testCase_testStepSheetName - 1].value
            print caseStepSheetName
            # print caseStepSheetName
            # 根据用例步骤名获取步骤sheet对象
            stepSheet = excelObj.getSheetByName(caseStepSheetName)
            # 获取步骤sheet中步骤数
            stepNum = excelObj.getRowsNumber(stepSheet)

            # print stepNum
            # 记录测试用例i的步骤成功数
            successfulSteps = 0
            if i.value   and i.value.lower()=="y1":
                requiredCase+=1
                # #获取“测试用例”表中第idx+2行数据
                # caseRow = excelObj.getRow(caseSheet,idx+2)
                # #获取“测试用例”中“步骤sheet”单元格的名字
                # caseStepSheetName = caseRow[testCase_testStepSheetName-1].value
                # print caseStepSheetName
                # #print caseStepSheetName
                # #根据用例步骤名获取步骤sheet对象
                # stepSheet = excelObj.getSheetByName(caseStepSheetName)
                # #获取步骤sheet中步骤数
                # stepNum = excelObj.getRowsNumber(stepSheet)
                # #print stepNum
                # #记录测试用例i的步骤成功数
                # successfulSteps = 0
                print u"开始执行用例 %s" %caseRow[testCase_testCaseName-1].value
                for step in xrange(2,stepNum+1):

                    #步骤sheet中的第一行为标题行，无须执行
                    #获取步骤sheet中第step行对象
                    stepRow=excelObj.getRow(stepSheet,step)
                    # stepNextRow=excelObj.getRow(stepSheet,step+1)
                    # nextIsExecuteColumn=stepNextRow[testCase_isExecute-1].value
                    print stepRow[0].value
                    #获取关键字为调用对象
                    keyWord = stepRow[testStep_keyWords-1].value
                    print keyWord
                    #获取操作元素定位方式作为调用函数的参数
                    locationType = stepRow[testStep_locationType - 1].value

                    #获取操作元素定位表达式作为调用函数的参数
                    locatorExpression = stepRow[testStep_locatorExpression - 1].value
                    #获取操作值作为调用函数的参数
                    operateValue = stepRow[testStep_operateValue-1].value
                    #将操作值为数字类型的数据专程字符串类型，方便字符串拼接
                    if isinstance(operateValue,long):
                        operateValue = str(operateValue)

                    expressionStr = ""
                    #构造需要执行的python语句
                    #对应的是pageAction.py文件中的页面动作函数调用的字符串标识
                    #keyWord 、operateValue、locationType、locatorExpression
                    if keyWord and operateValue and locationType is None and locatorExpression is None:
                        expressionStr = keyWord.strip()+"(u'"+operateValue+"')"
                        print expressionStr
                    elif keyWord and operateValue is None and locationType is None and locatorExpression is None:
                        expressionStr = keyWord.strip()+"()"
                    elif keyWord and locationType and operateValue and locatorExpression is None:
                        expressionStr = keyWord.strip()+"('"+locationType.strip()+"'u'"+operateValue+"',"
                    elif keyWord and locationType and locatorExpression and operateValue:
                        expressionStr = keyWord.strip()+"('"+locationType.strip()+"','"+\
                                        locatorExpression.replace("'",'"').strip()+"',u'"+operateValue+"')"
                    elif keyWord and locationType and locatorExpression and operateValue is None:
                        expressionStr = keyWord.strip()+"('" + locationType.strip()+"','"+\
                                        locatorExpression.replace("'",'"').strip()+"')"

                    try:
                        #通过eval函数，将拼接的页面动作函数用调用的字符串表示
                        #当成有效的python表达式执行，从而执行测试步骤的sheet中
                        #关键字在PageAction.py文件中对应的映射方法，来完成对页面元素的操作
                        eval(expressionStr)
                        #在测试执行时间列写入执行时间
                        excelObj.writeCellCurrentTime(stepSheet,rowNo=step,colsNo=testStep_runTime)
                    except Exception,e:
                        #获取异常屏幕图片
                        capturePic  = capture_screen()
                        #获取详细的异常堆栈信息
                        errorInfo = traceback.format_exc()
                        #在测试步骤的Sheet中写入失败信息
                        writeTestResult(stepSheet,step,"caseStep","faild",errorInfo,capturePic)


                        print u"步骤%s执行失败"%stepRow[testStep_testStepDescribe-1].value

                    else:
                        #在测试步骤Sheet中写入成功信息
                        writeTestResult(stepSheet,step,"caseStep","pass")
                        #每成功一次，successfulSteps变量自增1
                        successfulSteps +=1
                        print u"步骤%s执行通过" % stepRow[testStep_testStepDescribe - 1].value
                if successfulSteps==stepNum - 1:
                    #当测试用例步骤sheet中所有的步骤都执行成功
                    #认为此测试用例执行通过，然后将成功信息写入
                    #测试用例工作表中，否则写入失败信息
                    writeTestResult(caseSheet,idx+2,"testCase","pass")
                    successfulCase += 1
                else:
                    writeTestResult(caseSheet,idx+2,"testCase","faild")

            # if i.value and i.value.lower()=="x":



        print u"共%d条用例，%d条需要被执行，本次执行通过%d条."%(excelObj.getRowsNumber(caseSheet)-1,requiredCase,successfulCase)

    except Exception, e:
        #打印详细的异常堆栈信息
        print traceback.print_exc()

if __name__=='__main__':
    runCase()


