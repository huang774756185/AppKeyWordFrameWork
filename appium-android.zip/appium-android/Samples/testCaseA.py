#encoding=utf-8
from util.ParseExcel import ParaseExcel
from Actions.UiHandle import *
from config.VarConfig import *
import traceback
import sys



reload(sys)
sys.setdefaultencoding("utf-8")


excelObj = ParaseExcel()#创建excel表格操作对象
excelObj.loadWorkBook(dataFilePath)#将测试用例excel对象加载到内存中

def writeTestResult(sheetObj , rowNo , colsNo, testResult, errorInfo = None, picPath= None):
    #测试结果成功为绿色，失败为红色
    colorDict = {"pass":"green","faild":"red"}
    #区分测试用例测试结果及单个用例执行结果列表
    colsDict ={
        "testCase":[testCase_runTime,testCase_testResult],
        "caseStep":[testStep_runTime,testStep_testResult]
    }
    try:
        #写入测试时间
        excelObj.writeCellCurrentTime(sheetObj ,rowNo=rowNo ,colsNo=colsDict[colsNo][0])
        #写入测试结果
        excelObj.writeCell(sheetObj,content=testResult, rowNo=rowNo, colsNo=colsDict[colsNo][1],
                           style=colorDict[testResult])
        #写入异常信息
        if errorInfo and picPath:
            excelObj.writeCell(sheetObj,content=errorInfo, rowNo=rowNo,colsNo=testStep_errorInfo)#异常信息
            excelObj.writeCell(sheetObj,content=picPath,rowNo=rowNo,colsNo=testStep_errorPic)#异常截图
        else:
            excelObj.writeCell(sheetObj,content="",rowNo=rowNo ,colsNo=testStep_errorInfo)
            excelObj.writeCell(sheetObj,content="",rowNo=rowNo, colsNo=testStep_errorPic)


    except Exception, e:
        print u"写入excel出错,",traceback.print_exc()

def runCase():
    try:
        #根据sheet名获取sheet对象
        caseSheet = excelObj.getSheetByName(u"测试用例")
        #获取是否执行sheet中“是否执行”单元格对象
        isExecuteColumn = excelObj.getColumn(caseSheet,testCase_isExecute)
        #记录执行成功的测试用例个数
        successfulCase = 0
        #记录需要执行的用例个数
        requiredCase = 0
        for idx , i in enumerate(isExecuteColumn[1:]):
            #第一行为标题行，无需执行，从第二行开始执行
            if i.value and i.value.lower()=="y":
                requiredCase+=1
                #获取“测试用例”表中第二行开始的用例。idx为索引，从0开始，
                caseRow = excelObj.getRow(caseSheet,idx+2)
                #获取用例名字
                caseStepSheetName = caseRow[testCase_testStepSheetName-1].value
                #根据用例中步骤单元格名字获取stepSheet对象
                stepSheet = excelObj.getSheetByName(caseStepSheetName)
                #获取步骤表执行步骤数量
                stepNum = excelObj.getRowsNumber(stepSheet)
                #记录测试用例步骤执行成功数量
                successfulSteps = 0
                for step in xrange (2,stepNum+1):
                    #执行步骤sheet中的第一行为标题行，无需执行
                    #获取步骤sheet中第step对象
                    stepRow = excelObj.getRow(stepSheet,step)
                    #获取关键字
                    keyWord = stepRow[testStep_keyWords-1].value
                    print keyWord
                    #获取操作元素定位方式作为调用函数的参数
                    locationType = stepRow[testStep_locationType-1].value
                    #获取定位表达式
                    locatorExpression = stepRow[testStep_locatorExpression-1].value
                    #获取操作值
                    operateValue = stepRow[testStep_operateValue-1].value
                    #将操作值变为字符串类型
                    if isinstance(operateValue,long):
                        operateValue = str(operateValue)

                    #表达式拼接
                    expressionStr = ""
                    if keyWord and operateValue and locationType is None and locatorExpression is None:
                        expressionStr = keyWord.strip() + "(u'" + operateValue + "')"
                        print expressionStr
                    elif keyWord and operateValue is None and locationType is None and locatorExpression is None:
                        expressionStr = keyWord.strip() + "()"
                        print expressionStr
                    elif keyWord and locationType and operateValue and locatorExpression is None:
                        expressionStr = keyWord.strip() + "('" + locationType.strip() + "'u'" + operateValue + "',"
                        print expressionStr
                    elif keyWord and locationType and locatorExpression and operateValue:
                        expressionStr = keyWord.strip() + "('" + locationType.strip() + "','" + \
                                        locatorExpression.replace("'", '"').strip() + "',u'" + operateValue + "')"
                        print expressionStr
                    elif keyWord and locationType and locatorExpression and operateValue is None:
                        expressionStr = keyWord.strip() + "('" + locationType.strip() + "','" + \
                                        locatorExpression.replace("'", '"').strip() + "')"
                        print expressionStr

                    try:
                        eval(expressionStr)
                        #写入测试执行时间
                        excelObj.writeCellCurrentTime(stepSheet,rowNo=step,colsNo=testStep_runTime)
                    except Exception, e:
                        capturePic = capture_screen()
                        #获取详细的异常堆栈信息
                        errorInfo = traceback.format_exc()
                        #在测试步骤的sheet中写入失败信息
                        writeTestResult(stepSheet, step, "caseStep", "faild", errorInfo, capturePic)
                        print u"步骤%s执行失败"%stepRow[testStep_testStepDescribe-1].value
                    else:
                        #在测试步骤sheet中写入成功信息
                        writeTestResult(stepSheet, step, "caseStep", "pass")
                        successfulSteps +=1
                        print u"步骤%s执行通过" % stepRow[testStep_testStepDescribe - 1].value

                if successfulSteps==stepNum-1:
                    #当一个步骤sheet中所有的步骤都执行成功
                    #则认为此用例执行通过，将成功信息写入，否则视为用例失败
                    writeTestResult(caseSheet, idx+2, "testCase", "pass")
                    successfulCase += 1
                else:
                    writeTestResult(caseSheet, idx+2,"testCase", "faild")
        print u"共%d条用例，%d条需要被执行，本次执行通过%d条，"%(excelObj.getRowsNumber(caseSheet)-1 ,
                                             requiredCase,successfulCase)

    except Exception, e:
        #打印详细的异常堆栈信息
        print traceback.print_exc()

def runCase1():
    global step
    try:
        #根据sheet名获取sheet对象
        caseSheet = excelObj.getSheetByName(u"测试用例")
        #获取是否执行sheet中“是否执行”单元格对象
        isExecuteColumn = excelObj.getColumn(caseSheet,testCase_isExecute)
        #记录执行成功的测试用例个数
        successfulCase = 0
        #记录需要执行的用例个数
        requiredCase = 0
        for idx , i in enumerate(isExecuteColumn[1:]):
            #第一行为标题行，无需执行，从第二行开始执行
            if  i.value.lower()=="y":
                requiredCase+=1
                #获取“测试用例”表中第二行开始的用例。idx为索引，从0开始，
                caseRow = excelObj.getRow(caseSheet,idx+2)
                #获取用例名字
                caseStepSheetName = caseRow[testCase_testStepSheetName-1].value
                #根据用例中步骤单元格名字获取stepSheet对象
                stepSheet = excelObj.getSheetByName(caseStepSheetName)
                #获取步骤表执行步骤数量
                stepNum = excelObj.getRowsNumber(stepSheet)
                #记录测试用例步骤执行成功数量
                successfulSteps = 0
                # 执行步骤sheet中的第一行为标题行，无需执行
                # 获取步骤sheet中第step对象
                stepRow = excelObj.getRow(stepSheet, step)
                # 获取关键字
                keyWord = stepRow[testStep_keyWords - 1].value
                print keyWord
                # 获取操作元素定位方式作为调用函数的参数
                locationType = stepRow[testStep_locationType - 1].value
                # 获取定位表达式
                locatorExpression = stepRow[testStep_locatorExpression - 1].value
                # 获取操作值
                operateValue = stepRow[testStep_operateValue - 1].value
                # 将操作值变为字符串类型
                runStep(2)
                if successfulSteps==stepNum-1:
                    #当一个步骤sheet中所有的步骤都执行成功
                    #则认为此用例执行通过，将成功信息写入，否则视为用例失败
                    writeTestResult(caseSheet, idx+2, "testCase", "pass")
                    successfulCase += 1
                else:
                    writeTestResult(caseSheet, idx+2,"testCase", "faild")
        print u"共%d条用例，%d条需要被执行，本次执行通过%d条，"%(excelObj.getRowsNumber(caseSheet)-1 ,
                                             requiredCase,successfulCase)

    except Exception, e:
        #打印详细的异常堆栈信息
        print traceback.print_exc()

def runStep(num):
    print 5






if __name__=='__main__':
    runCase()





