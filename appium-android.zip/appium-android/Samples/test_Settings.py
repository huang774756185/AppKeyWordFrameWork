#encoding=utf-8

from appium import webdriver
from Actions import Login
from Actions import LaunchApp



def changePassWord():
    global driver
    # driver = LaunchApp.launchApp()
    print u"点击修改页"
    driver.find_element_by_xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout[1]/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.LinearLayout")
def settings():
    LaunchApp.launchApp()
    driver=LaunchApp.launchApp()
    Login.login(driver,"17679058025","123456")
    print u"点击会员"
    driver.find_element_by_id("com.cgbsoft.privatefund:id/fl_bottom_nav_right_second").click()
    print u"点击设置按钮"
    driver.find_element_by_id("com.cgbsoft.privatefund:id/mine_title_set_id").click()
    changePassWord()


if __name__=='_main__':
    settings()