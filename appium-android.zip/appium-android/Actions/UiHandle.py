#encoding=utf-8
from appium import webdriver
from config.VarConfig import *
from util.ObjectUi import getElement
from util.WaitUtil import WaitUtil
from util.DirAndTime import *
import time
from appium.webdriver.common.touch_action import TouchAction
# from selenium import webdriver
from selenium.webdriver.common.touch_actions import TouchActions
import pymysql
import os


#定义全局driver变量
driver = None
#定义全局等待类实例对象
waitUtil = None
def launchApp_sxy():
    global driver,waitUtil
    try:
        driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub', desired_caps_sxy)
        waitUtil = WaitUtil(driver)
    except Exception, e:
        raise e

def launchApp_sxy_noReset():
    global driver,waitUtil
    try:
        driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub', desired_caps_sxy_noReset)
        waitUtil = WaitUtil(driver)
    except Exception, e:
        raise e

def launchApp_smy():
    global driver, waitUtil
    try:
        driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub',desired_caps_smy)
        waitUtil = WaitUtil(driver)
    except Exception, e:
        raise e

def launchApp_smy_noReset():
    global driver, waitUtil
    try:
        driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub',desired_caps_smy_noReset)
        waitUtil = WaitUtil(driver)
    except Exception, e:
        raise e

def click(locationType, locatorExpression,*arg):
    #点击操作
    global driver
    try:
        getElement(driver,locationType,locatorExpression).click()
    except Exception, e:
        raise e

def hide_keyboard():
    global driver
    try:
        driver.hide_keyboard()
    except Exception, e:
        raise e

def sleep(sleepSeconds,*arg):
    #强制等待
    try:
        time.sleep(int(sleepSeconds))
    except Exception, e:
        raise e

def input_string(locationType, locatorExpression,inputContent):
    #输入内容
    global driver
    try:
        getElement(driver,locationType,locatorExpression).send_keys(inputContent)
    except Exception, e:
        raise e

def adb_input_string(inputString):
    try:
        os.system("adb shell input text %s" %inputString)
        kill_port('5307')
    except Exception as e:
        raise e

def adb_tap(inputString):
    try:
        os.system("adb shell input tap  %s" %inputString)

    except Exception as e:
        raise e
def clear(locationType, locatorExpression, *arg):
    #清除数据框默认内容
    global driver
    try:
        getElement(locationType,locatorExpression).clear()
    except Exception, e:
        raise e

def hideKeyboard():
    #隐藏键盘
    global driver
    try:
        driver.hide_keyboard()
    except Exception, e:
        raise e

def assert_string_in_pagesource(asassertString,*arg):
    "'断言页面中是否存在关键字符串'"
    global driver
    try:
        assert asassertString in driver.page_source,u"%s not found in page source!"%asassertString
    except AssertionError,e:
        raise AssertionError(e)
    except Exception, e:
        raise e

def waitVisibilityOfElementLocated(locationType, locatorExpression, *arg):
    "'显示等待页面元素出现在DOM中，并且可见， 存在则返回该页面元素'"
    global waitUtil
    try:
        waitUtil.visibilityOfElementLocated(locationType , locatorExpression)
    except Exception, e:
        raise e

def assert_title(titleStr, *arg):
    #断言页面标题是否存在给定的关键字
    global driver
    try:
        assert titleStr in driver.title,u"%s not found in page title"%titleStr
    except AssertionError,e:
        raise AssertionError(e)
    except Exception, e:
        raise e


def pressKeyBack():
    global driver
    try:
        driver.press_keycode(4)
    except Exception, e:
        raise e


def tripClick(locationType, locatorExpression, *arg):
    global driver
    try:
        click(locationType=locationType, locatorExpression=locatorExpression)
        click(locationType=locationType, locatorExpression=locatorExpression)
        click(locationType=locationType, locatorExpression=locatorExpression)
    except Exception, e:
        raise e

def doubleClick(locationType, locatorExpression,*arg):
    global driver
    try:
        click(locationType=locationType,locatorExpression=locatorExpression)
        click(locationType=locationType, locatorExpression=locatorExpression)
    except Exception, e:
        raise

def capture_screen(*arg) :
    #屏幕截图
    global driver
    currTime = getCurrentTime()
    picNameAndPath = str(createCurrentDateDir())+"\\"+str(currTime)+".png"
    try:
        driver.get_screenshot_as_file(picNameAndPath.replace("\\", r"\\"))

    except Exception, e:
        raise e
    else:
        return picNameAndPath

def closeApp(*arg):
    global driver
    try:
        driver.quit()
    except Exception, e:
        raise e

#滑动屏幕
def getsize():
    global driver
    x = driver.get_window_size()['width']
    y = driver.get_window_size()['height']
    return (x, y)
def swipeUp(t):
    global driver
    coordinate = getsize()
    x1 = int(coordinate[0]*0.5)
    y1 = int(coordinate[1]*0.75)#起始Y坐标
    y2 = int(coordinate[1]*0.25)#终点Y坐标
    driver.swipe(x1, y1, x1, y2, t)

def sql_count(db,tabName,id):
    class sqlError(Exception):
        pass
    db = pymysql.connect(host="192.168.19.199", user="root", password="simuyun2014#@!", db=db, port=3307)
    try:
        sql = "select * from " + tabName + " where user_id='" + id + "'"
        cur = db.cursor()
        count = cur.execute(sql)
        db.close()

        if count <= 0:
            try:
                raise sqlError("云淘申领失败")

            except sqlError as e:
                print "失败"
                raise e
        else:
            print "申请成功"
    except Exception, e:
        raise e


def kill_port(port):
    # 查找端口的pid
    find_port= 'netstat -aon | findstr %s' % port
    result = os.popen(find_port)
    text = result.read()
    pid= text [-5:-1]
    # 占用端口的pid
    find_kill= 'taskkill -f -pid %s' %pid
    print(find_kill)
    result = os.popen(find_kill)
    return result.read()


def tap(X,Y):
    global driver
    try:
        TouchAction(driver).tap(x=int(X), y=int(Y)).perform()
    except Exception, e:
        raise e

def switch_to_webview():
    global driver
    contexts = driver.contexts
    try:
        driver.switch_to.context(contexts[-1])
        print "切换到webview"
    except Exception ,e:
        raise e

def switch_to_native():
    global driver
    contexts = driver.contexts
    try:
        driver.switch_to.context("NATIVE_APP")
        print "切换到native"
    except Exception, e:
        raise e

def web_tap_element(locationType, locatorExpression):
    try:
        element = getElement(driver, locationType=locationType, locatorExpression=locatorExpression)
        tas = TouchActions(driver)
        tas.tap(element).perform()
    except Exception, e:
        raise e

def native_tap_element(locationType, locatorExpression):
    try:
        element = getElement(driver, locationType=locationType, locatorExpression=locatorExpression)
        ta = TouchAction(driver)
        ta.tap(element).perform()
    except Exception, e:
        raise e



if __name__=='__main__':
    # sql_count("test",)
    # capture_screen()
    # adb_tap("364 1113")
    # adb_input_string("123456")
    # launchApp_smy_noReset()
    launchApp_smy_noReset()
    sleep(10)

    switch_to_webview()
    sleep(1)
    # element = getElement(driver,'xpath','//*[@id="detail"]/div[4]/a[2]')
    # path1 = '//*[@id="detail"]/div[4]/a[2]'
    # path2 = '//*[@id="detail"]/div[4]/a[2]'
    #
    #
    # # click('xpath','//*[@id="detail"]/div[4]/a[2]')
    # # location = element.getLocation()
    # # size = element.getSize()
    # # print driver.get_window_size()['height']
    # # print element.location
    # # print element.size
    #
    # # x = element.location['x'] + element.size['width']/2.0
    # # print x
    # # y = element.location['y'] + element.size['height']/2.0
    # # print y
    # # # point=[(x,y)]
    # tas = TouchActions(driver)
    #
    # tas.tap(element).perform()
    tap('xpath','//*[@id="detail"]/div[4]/a[2]')

    print '点击'
    switch_to_native()
    print '切换成功'
    # sleep(2)
    # print 'sleep'
    # tap(350, 1214)


