#encoding=utf-8
import pymysql
import os
#
# os.system("adb shell input text 100")

db = pymysql.connect(host="192.168.19.199", user="root", password="simuyun2014#@!", db="test", port=3307)

#获取操作游标
cur = db.cursor()
#查询操作
sql = "select * from bd_adviser_info where id='0000c88a3c364224a7ab20056b96d3da'"
count = cur.execute(sql)
print type(count)
print count
db.close()