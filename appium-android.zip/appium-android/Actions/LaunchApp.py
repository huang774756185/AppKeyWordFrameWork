#encoding=utf-8
from appium import webdriver
from config.VarConfig import desired_caps




def launchApp():

    webdriver.Remote('http://127.0.0.1:4723/wd/hub', desired_caps)


if __name__=='__main__':
    launchApp()
