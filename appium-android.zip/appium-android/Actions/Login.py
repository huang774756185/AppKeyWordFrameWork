#encoding=utf-8
from Actions import LaunchApp
import time

def login( userName,passord):
    driver= LaunchApp.launchApp()
    time.sleep(5)
    e=driver.find_element_by_id("com.android.packageinstaller:id/permission_allow_button")
    e.click()
    e.click()
    e.click()
    time.sleep(4)
    eName = driver.find_element_by_id("com.cgbsoft.privatefund:id/et_al_username")
    eName.click()
    eName.send_keys(userName)
    time.sleep(2)
    ePassword = driver.find_element_by_id("id")
    ePassword.click()
    ePassword.send_keys(passord)
    time.sleep(2)
    driver.find_element_by_id("com.cgbsoft.privatefund:id/btn_al_login").click()
    time.sleep(5)






if __name__=='__main__':

    print u"开始执行用例 %s" %u"很好"
    print u"投资"
    login.driver.find_element_by_id("com.cgbsoft.privatefund:id/tv_bottom_nav_left_second").click()
    print u"点击视频"
    login.find_element_by_xpath(r"/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget"
                                 ".FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view."
                                 "ViewGroup/android.widget.FrameLayout[1]/android.widget.LinearLayout/android.widget."
                                 "RelativeLayout/android.widget.HorizontalScrollView/android.widget.LinearLayout"
                                 "/android.support.v7.app.ActionBar.Tab[4]/android.widget.TextView").click()

