
driver = None
def closeDaliybonus():
    global driver
    try:
        driver.find_delement_by_id().click()

    except Exception , e:
        raise e
    else:
        print u"无弹窗"